#!/usr/bin/env bash
set -euo pipefail
cd /home/azureuser/petboutique-s6
curl --fail --silent http://127.0.0.1:8080/health
sudo cp -n /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.exp1-backup
sudo a2enmod proxy proxy_http
sudo cp apache-petboutique.conf /etc/apache2/sites-available/petboutique-s6.conf
sudo a2dissite 000-default
sudo a2ensite petboutique-s6
if sudo apache2ctl configtest; then
  sudo systemctl reload apache2
else
  sudo a2dissite petboutique-s6
  sudo a2ensite 000-default
  exit 1
fi
curl --fail --silent http://127.0.0.1/health
