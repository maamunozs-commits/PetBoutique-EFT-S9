#!/usr/bin/env bash
set -euo pipefail
cd /home/azureuser/petboutique-s6
trap 'sudo docker compose start api >/dev/null' EXIT
date -u
echo 'Contenedor web antes de detener API'
sudo docker compose ps -q web
sudo docker compose stop api
echo 'Web sin API: se espera HTTP 200'
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8080/health-web
echo 'API detenida: se espera HTTP 502'
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8080/health
sudo docker compose start api
for i in $(seq 1 20); do
  if curl -fsS http://127.0.0.1:8080/health; then break; fi
  sleep 1
done
echo
echo 'Contenedor web despues de recuperar API'
sudo docker compose ps -q web
sudo docker compose ps
