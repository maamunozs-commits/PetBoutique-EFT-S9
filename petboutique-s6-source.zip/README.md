# PetBoutique Experiencia 2 Semana 6

Implementado en vm-petboutique-lab el 20-09-2026. Caso académico sin pagos ni datos personales.

## Componentes

- web: HTML y Nginx, imagen independiente, 96 MiB y 0,25 CPU.
- api: ASP.NET Core 10, controlador conservado del caso anterior, 320 MiB y 0,75 CPU.
- Compose: red bridge, API sin puerto publicado, web en 127.0.0.1:8080.
- Apache del host: proxy desde el puerto HTTP existente al contenedor web.
- ACR: acrpetboutiquemm260920.azurecr.io, repositorios petboutique/api y petboutique/web, etiqueta s6-v1; administrador deshabilitado.

## Construcción local o en VM

```sh
docker compose config --quiet
docker compose build
docker compose up -d
python3 verify.py http://127.0.0.1:8080
```

## Despliegue desde el registro

Autenticarse con una identidad autorizada de Azure y ejecutar `az acr login --name acrpetboutiquemm260920`. En la VM se usa sudo para Docker; la autenticación debe corresponder a ese contexto. No agregar contraseñas o tokens a .env.

```sh
cp .env.example .env
sudo docker compose pull
sudo docker compose up -d --no-build
sudo docker compose ps
python3 verify.py http://127.0.0.1:8080
```

`activate-proxy.sh` configura Apache, conserva una copia de la configuración previa y comprueba sintaxis. `test-isolation.sh` detiene brevemente la API y la recupera; ejecutarlo solo durante una ventana de prueba.

## Trazabilidad

El paquete fuente petboutique-s6-source.zip y azure-pipelines-s6.yml permiten que Azure Pipelines extraiga el código, construya ambas imágenes y ejecute los diez casos. La publicación inicial en ACR y la promoción a la VM fueron controladas manualmente por SSH, no un CD automático. Los digests de la entrega se conservan en el informe y el registro de imágenes.

## Recuperar el sitio anterior

```sh
sudo a2dissite petboutique-s6
sudo a2ensite 000-default
sudo apache2ctl configtest
sudo systemctl reload apache2
```

No ejecutar esa recuperación durante una demostración de S6. No se eliminaron los archivos originales de /var/www/html. El ensayo real realizado fue detener/iniciar la API, no un rollback a otra versión.

## Pendientes académicos

Grabar la presentación de Teams, insertar su enlace en el Word y completar el quiz individual. La infraestructura es un laboratorio de una VM: no aporta alta disponibilidad. ACR Basic, disco e IP pueden generar consumo aunque la VM se detenga; revisar costos antes de conservar el entorno a largo plazo.
